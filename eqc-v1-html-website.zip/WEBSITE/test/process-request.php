<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	
</head>

<body>

<h3>Success!</h3>

<?php
$requestSender = $_POST['requestSender'];
if($requestSender=="addSurah"){
	print"<p>We have a request from $requestSender \n";
}
else{
	print"<p>Could not determine origin of request \n";
}

?>


<?php

	print "<h1>Attempt to Connect to MySQL</h1>";
	//**********************************************
	//*
	//*  Connect to MySQL and Database
	//*
	//**********************************************

	$db = mysqli_connect('easyquranclass.com','ldzwhazs','vyJ0[f19kQY+1G', 'ldzwhazs_easyQuranClassDataBase');

	if (!$db)
	{
		print "<h1>Unable to Connect to MySQL</h1>";
	}
	else{
		print "<h1>Connected to MySQL</h1>";
	}




	//**********************************************
	//*
	//*  Add Surah into Table
	//*
	//**********************************************


	if($requestSender=="addSurah"){
		$surahName = $_POST['surahName'];
		$surahNumber = $_POST['surahNumber'];
		$surahRuku = $_POST['surahRuku'];
		$surahAyaat = $_POST['surahAyaat'];
		$origin = $_POST['origin'];
		$surahDescription = $_POST['surahDescription'];

		$statement 	= "insert into surahIndex (surahNumber, surahName, surahOrigin, totalRuku, totalAyaat, surahDescription) ";
		$statement .= "values (";
		$statement .= "'".$surahNumber."', '".$surahName."', '".$origin."', '".$surahRuku."', '".$surahAyaat."', '".$surahDescription."'";
		$statement .= ")";

		$result = mysqli_query($db, $statement);

		if ($result)
		{
			print "<h1>Result: $myssn</h1>" ;
		} else {
			$errno = mysqli_errno($db);

			if ($errno == '1062') {
				echo "<p style='color: red'>Author with SSN of ".$myssn. " is already in Table ";
			} else {
				echo("<h4>MySQL No: ".mysqli_errno($db)."</h4>");
				echo("<h4>MySQL Error: ".mysqli_error($db)."</h4>");
				echo("<h4>SQL: ".$statement."</h4>");
				echo("<h4>MySQL Affected Rows: ".mysqli_affected_rows($db)."</h4>");
			}

			print "<h1>Result: NotAdded </h1>" ;
		}


	}
	
?>







</body>
</html>
