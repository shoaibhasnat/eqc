<head>
  <title>Easy Quran Class</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/menu.css">
  <link rel="stylesheet" href="css/home.css">
</head>

<boody>
  <!--=======================================================================================================================-->
  <!--Cover Image-->

  <div class="cover-image" id="home">
    <div class="cover-image-top-layer">


      <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->
      <!--                Header Menu Code             -->
      <section class="top-nav">
        <div class="topnav" id="myTopnav">
          <a href="#home" class="active">Home</a>
          <a href="#about">About Class</a>
          <a href="#about">Surah Index</a>

          <div class="dropdown">
            <button class="dropbtn">Classes <i class="fa fa-caret-down" style="color: white;"></i>
            </button>
            <div class="dropdown-content">
              <a href="#">Morning Class</a>
              <a href="#">Evening Class</a>
            </div>
          </div>
          <!--
          <div class="dropdown">
            <button class="dropbtn">Resources <i class="fa fa-caret-down" style="color: white;"></i>
            </button>
            <div class="dropdown-content">
              <a href="#">Readings</a>
              <a href="#">Audios</a>
              <a href="#">Videos</a>
            </div>
          </div>
          -->
          <a href="https://www.facebook.com/Amjadquranclass">Contact</a>
          <a href="javascript:void(0);" style="font-size:15px; color:white;" class="icon"
            onclick="myFunction()">&#9776;</a>
        </div>

        <script>
          function myFunction() {
            var x = document.getElementById("myTopnav");
            if (x.className === "topnav") {
              x.className += " responsive";
            } else {
              x.className = "topnav";
            }
          }
        </script>

      </section>
      <!--++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++-->

      <!--*******************************************************************************************************-->
      <!--                   Cover Text          -->
      <div class="myheading1" style="padding: 25vh 0vh 0vh 0vh;">
        "And that there is not for man except that [good] for which he strives"
      </div>
      <div class="myheading2">
        - The Holy Quran 53:39 Surah AN-NAJM
      </div>
      <!--*******************************************************************************************************-->

    </div>
  </div>
  <!--=======================================================================================================================-->

  <div id="about" class="about-section" id="about">
    <div class="myheading1" style="color:gray;">
      Introduction to Quran Class
    </div>
    <div class="iframe-cover">
      <iframe class="myiframe" src="https://www.youtube.com/embed/GS5ald12qJc" frameborder="0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </div>
    <div id="about-text">
      "An introductory lecture to Quran Class by Muhammad Amjad Chaudhry"
    </div>
  </div>

  <!--=======================================================================================================================-->

  
    <div id="facebook-section">

      <div class="myheading1" style="color:#3b5998;" >
        Join Class on Facebook
      </div>

      <div class="iframe-cover">
        <iframe class="myiframe"
          src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FAmjadquranclass%2F&tabs=timeline&width=560&height=315&small_header=true&adapt_container_width=false&hide_cover=false&show_facepile=true&appId"
          width="560" height="315" style="border:none;overflow:hidden" scrolling="yes" frameborder="0"
          allowTransparency="true" allow="encrypted-media"></iframe>
      </div>


    </div>


    <div id="youtube-section">

      <div class="myheading1" style="color:#c4302b;" >
        Join Class on Youtube
      </div>

      <div class="iframe-cover">
        <iframe class="myiframe" src="https://www.youtube.com/embed/GS5ald12qJc" frameborder="0"
          allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
      </div>

    </div>
  

  <!--=======================================================================================================================-->

  <div class="footer">
    
    <div id="footer-text" class="mytext1">
      &copy; All rights reserved by 
      <a href="https://www.easyquranclass.com">
      easyquranclass.com
      </a>
    </div>

  </div>

</boody>