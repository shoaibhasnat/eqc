<html>
<head><title>Add a Surah - Easy Quran Class</title>
<style>body {font-family: Arial, Helvetica, sans-serif; font-size: 16px;}</style>

<body>

	<form method="post" action="process-request.php">
		<p>Surah Name:</p>
		<input type="text" name="surahName" size="30"/>
		<p>Surah Number:</p>
		<input type="number" name="surahNumber" min="1" max="114">
		<p>Total Ruku:</p>
		<input type="number" name="surahRuku" min="1" max="50">
		<p>Total Ayaat:</p>
		<input type="number" name="surahAyaat" min="3" max="300">
		<p>Origin:</p>
		<input type="radio" name="origin" value="Makki" checked="checked"> Makki Surah
		<input type="radio" name="origin" value="Madni"> Madni Surah
		<p>Surah Description:</p>
		<textarea name="surahDescription" rows="7" cols="50"> </textarea>
		
		<input type="hidden" name="requestSender" value="addSurah">
		
		<input type="submit" value="add-surah">
	</form>


</body>

</html>